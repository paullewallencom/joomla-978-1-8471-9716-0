********************************************
Joomla 1.5 Theme Design
********************************************

Chapter 1 - No Code
Chapter 2 - Code Present
Chapter 3 - Code Present
Chapter 4 - Code Present
Chapter 5 - Code Present
Chapter 6 - No Code
Chapter 7 - Code Present
Chapter 8 - Code Present
Chapter 9 - Code Present



Note: This folder contains text files that contain the code for the respective chapters.